import React, { useState } from "react";
import { Modal, Button, Form } from "react-bootstrap";

/**
 * AppointmentScheduler Component
 * 
 * This component allows users (patients) to:
 * - Open a floating "Schedule an Appointment" button.
 * - Filter available appointments based on Date, Time, Location, Type, Insurance, and Provider.
 * - Select an appointment from the filtered results.
 * - Confirm their appointment selection via a modal.
 *
 * Features:
 * - Uses dummy data for now but will later connect to provider availability.
 * - Results are displayed inside the filtering modal after searching.
 * - Clicking an appointment opens a confirmation modal before adding it to the calendar.
 */

const AppointmentScheduler = () => {
  // State for controlling modals
  const [showFilterModal, setShowFilterModal] = useState(false); // Controls the filtering modal
  const [showConfirmModal, setShowConfirmModal] = useState(false); // Controls the confirmation modal
  const [selectedAppointment, setSelectedAppointment] = useState(null); // Stores the selected appointment

  // Filters entered by the user
  const [filters, setFilters] = useState({
    dateStart: "",
    dateEnd: "",
    timeStart: "",
    timeEnd: "",
    location: "",
    type: "",
    insurance: "",
    provider: "",
  });

  // Dummy appointment data (for testing)
  const dummyAppointments = [
    { id: 1, provider: "Dr. Smith", location: "Knoxville Dental", type: "Dental Checkup", date: "2025-02-15", time: "3:00 PM", duration: "30 min" },
    { id: 2, provider: "Dr. Johnson", location: "East TN Healthcare", type: "General Consultation", date: "2025-03-10", time: "9:30 AM", duration: "45 min" },
    { id: 3, provider: "Dr. Patel", location: "Knoxville Clinic", type: "Eye Exam", date: "2025-04-05", time: "1:00 PM", duration: "20 min" },
  ];

  /**
   * Handles user input for filters
   * @param {Event} e - The change event from the form input
   */
  const handleFilterChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  /**
   * Handles the search functionality when the "Search" button is clicked.
   * In the future, this will call an API to fetch real appointment data.
   */
  const handleSearch = () => {
    setShowFilterModal(false); // Close the filter modal
  };

  /**
   * Handles when a user selects an appointment from the filtered list.
   * @param {Object} appointment - The selected appointment object
   */
  const handleSelectAppointment = (appointment) => {
    setSelectedAppointment(appointment);
    setShowConfirmModal(true);
  };

  return (
    <>
      {/* Floating "Schedule an Appointment" Button */}
      <Button
        variant="primary"
        style={{ position: "fixed", bottom: "20px", right: "20px", borderRadius: "50%", width: "60px", height: "60px" }}
        onClick={() => setShowFilterModal(true)}
      >
        +
      </Button>

      {/* Filtering Modal */}
      <Modal show={showFilterModal} onHide={() => setShowFilterModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Schedule an Appointment</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            {/* Date Range Filter */}
            <Form.Group>
              <Form.Label>Date Range</Form.Label>
              <div className="d-flex">
                <Form.Control type="date" name="dateStart" onChange={handleFilterChange} />
                <span className="mx-2">to</span>
                <Form.Control type="date" name="dateEnd" onChange={handleFilterChange} />
              </div>
            </Form.Group>

            {/* Time Range Filter */}
            <Form.Group className="mt-2">
              <Form.Label>Time Range</Form.Label>
              <div className="d-flex">
                <Form.Control type="time" name="timeStart" onChange={handleFilterChange} />
                <span className="mx-2">to</span>
                <Form.Control type="time" name="timeEnd" onChange={handleFilterChange} />
              </div>
            </Form.Group>

            {/* Location Filter */}
            <Form.Group className="mt-2">
              <Form.Label>Location</Form.Label>
              <Form.Control type="text" name="location" onChange={handleFilterChange} />
            </Form.Group>

            {/* Appointment Type Filter */}
            <Form.Group className="mt-2">
              <Form.Label>Appointment Type</Form.Label>
              <Form.Control as="select" name="type" onChange={handleFilterChange}>
                <option value="">Select</option>
                <option value="Dental Checkup">Dental Checkup</option>
                <option value="General Consultation">General Consultation</option>
                <option value="Eye Exam">Eye Exam</option>
              </Form.Control>
            </Form.Group>

            {/* Insurance Filter */}
            <Form.Group className="mt-2">
              <Form.Label>Insurance Accepted</Form.Label>
              <Form.Control type="text" name="insurance" onChange={handleFilterChange} />
            </Form.Group>

            {/* Provider Name Filter */}
            <Form.Group className="mt-2">
              <Form.Label>Provider Name</Form.Label>
              <Form.Control type="text" name="provider" onChange={handleFilterChange} />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowFilterModal(false)}>Close</Button>
          <Button variant="primary" onClick={handleSearch}>Search</Button>
        </Modal.Footer>
      </Modal>

      {/* Appointment Confirmation Modal */}
      <Modal show={showConfirmModal} onHide={() => setShowConfirmModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Confirm Appointment</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedAppointment && (
            <>
              <p><strong>Provider:</strong> {selectedAppointment.provider}</p>
              <p><strong>Location:</strong> {selectedAppointment.location}</p>
              <p><strong>Type:</strong> {selectedAppointment.type}</p>
              <p><strong>Date:</strong> {selectedAppointment.date}</p>
              <p><strong>Time:</strong> {selectedAppointment.time}</p>
              <p><strong>Duration:</strong> {selectedAppointment.duration}</p>
            </>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowConfirmModal(false)}>Cancel</Button>
          <Button variant="primary" onClick={() => setShowConfirmModal(false)}>Confirm</Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default AppointmentScheduler;
